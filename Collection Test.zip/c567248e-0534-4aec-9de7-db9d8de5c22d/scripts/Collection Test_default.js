

function TextBox2_change(ctrl) { 
  console.log('Inside textbox2_1 change');
}


async function TextBox1_change(ctrl) { 
  console.log('Inside Borrower Employer change');
  const objEmployerState = await elli.script.getObject('Dropdown1#1')
  objEmployerState.value('NY');
}


async function Dropdown1_change(ctrl) { 
  console.log('State dropdown change invoked');
  const loanObj = await elli.script.getObject('loan');
  const objBtn1 = await elli.script.getObject('Button1#1')
  objBtn1.visible(false);
  const objForeignAssets = await elli.script.getObject('Checkbox1#0')
  objForeignAssets.value('Y');
  loanObj.setFields({'4000': 'This is test'});
}


async function Button2_click(ctrl) { 
  const objBtn3 = await elli.script.getObject('Button3')
  objBtn3.visible(false);
}


async function Button3_click(ctrl) { 
  const objLoanType = await elli.script.getObject('Checkbox2')
  objLoanType.value('FHA');
}


async function TextBox7_change(ctrl) { 
  const objChkBox3 = await elli.script.getObject('Checkbox3#0')
  objChkBox3.value('Both');
}
